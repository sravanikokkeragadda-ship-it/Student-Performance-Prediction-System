import os
import joblib
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import train_test_split

FEATURES = [
    "attendance", "study_hours", "previous_marks", "internal_marks",
    "assignment_score", "assignments_completed", "participation"
]
TARGET = "final_score"

def main():
    os.makedirs("model", exist_ok=True)
    data = pd.read_csv("dataset/student_data.csv")
    X, y = data[FEATURES], data[TARGET]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42
    )

    model = RandomForestRegressor(
        n_estimators=200, random_state=42, max_depth=8
    )
    model.fit(X_train, y_train)

    pred = model.predict(X_test)
    mae = mean_absolute_error(y_test, pred)
    rmse = mean_squared_error(y_test, pred) ** 0.5
    r2 = r2_score(y_test, pred)

    artifact = {
        "model": model,
        "features": FEATURES,
        "metrics": {"mae": mae, "rmse": rmse, "r2": r2},
    }
    joblib.dump(artifact, "model/student_model.pkl")

    print("Model trained successfully.")
    print(f"MAE : {mae:.2f}")
    print(f"RMSE: {rmse:.2f}")
    print(f"R2  : {r2:.2f}")
    print("Saved: model/student_model.pkl")

if __name__ == "__main__":
    main()
