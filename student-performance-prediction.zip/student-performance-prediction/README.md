# 🎓 Student Performance Prediction System

A beginner-friendly machine learning project that predicts a student's expected final score from academic and engagement features.

## Features

- Student input form
- ML-based final score prediction
- Performance category
- Personalized improvement suggestions
- Simple Streamlit interface
- Saved Random Forest model
- Model evaluation with MAE, RMSE and R²

## Tech Stack

Python • Pandas • NumPy • Scikit-learn • Random Forest • Streamlit • Joblib • Git/GitHub

## Project Structure

```text
student-performance-prediction/
├── app.py
├── train_model.py
├── requirements.txt
├── README.md
├── .gitignore
├── dataset/
│   └── student_data.csv
└── model/
    └── student_model.pkl
```

## How to Run Locally

### 1. Create a virtual environment

Windows:

```bash
python -m venv venv
venv\Scripts\activate
```

### 2. Install dependencies

```bash
pip install -r requirements.txt
```

### 3. Train the model

```bash
python train_model.py
```

### 4. Start the application

```bash
streamlit run app.py
```

## ML Approach

The project treats final score as a regression target.

**Features:**
- Attendance
- Study hours
- Previous marks
- Internal marks
- Assignment score
- Assignments completed
- Class participation

**Model:** Random Forest Regressor

**Evaluation:** MAE, RMSE and R².

> The included CSV is a synthetic educational dataset created for demonstrating the project workflow. For an academic submission, replace it with a legitimate dataset and document its source.

## Interview Explanation

> "My project predicts a student's expected final score using machine learning. I used academic and engagement features such as attendance, study hours, previous marks, internal marks, assignments and participation. I split the data into training and testing sets, trained a Random Forest regression model, evaluated it using MAE, RMSE and R², saved the trained model with Joblib, and built a Streamlit interface for real-time prediction."

## Future Enhancements

- Add a larger real-world dataset
- Compare multiple regression algorithms
- Add explainable-AI feature importance
- Add student history and authentication
- Store predictions in a database
- Deploy to a cloud platform
