import joblib
import pandas as pd
import streamlit as st

st.set_page_config(
    page_title="Student Performance Predictor",
    page_icon="🎓",
    layout="centered"
)

@st.cache_resource
def load_artifact():
    return joblib.load("model/student_model.pkl")

artifact = load_artifact()
model = artifact["model"]

st.title("🎓 Student Performance Prediction")
st.caption("Machine-learning system for estimating a student's final score.")

with st.form("prediction_form"):
    st.subheader("Enter Student Details")

    col1, col2 = st.columns(2)
    with col1:
        attendance = st.slider("Attendance (%)", 0, 100, 75)
        study_hours = st.number_input("Study Hours / Day", 0.0, 15.0, 3.0, 0.5)
        previous_marks = st.number_input("Previous Marks (%)", 0.0, 100.0, 65.0)
        internal_marks = st.number_input("Internal Marks (%)", 0.0, 100.0, 65.0)
    with col2:
        assignment_score = st.number_input("Assignment Score (%)", 0.0, 100.0, 70.0)
        assignments_completed = st.number_input("Assignments Completed", 0, 10, 7)
        participation = st.slider("Class Participation (0-10)", 0, 10, 7)

    submitted = st.form_submit_button("Predict Performance", use_container_width=True)

if submitted:
    X = pd.DataFrame([{
        "attendance": attendance,
        "study_hours": study_hours,
        "previous_marks": previous_marks,
        "internal_marks": internal_marks,
        "assignment_score": assignment_score,
        "assignments_completed": assignments_completed,
        "participation": participation,
    }])

    prediction = float(model.predict(X)[0])
    prediction = max(0, min(100, prediction))

    st.divider()
    st.metric("Predicted Final Score", f"{prediction:.1f}%")

    if prediction >= 85:
        level = "Excellent 🌟"
    elif prediction >= 70:
        level = "Good 👍"
    elif prediction >= 50:
        level = "Average 🙂"
    else:
        level = "Needs Improvement ⚠️"

    st.subheader(f"Performance Level: {level}")

    suggestions = []
    if attendance < 75:
        suggestions.append("Improve attendance.")
    if study_hours < 3:
        suggestions.append("Increase daily study time.")
    if assignment_score < 70:
        suggestions.append("Focus more on assignments.")
    if participation < 5:
        suggestions.append("Participate more actively in class.")

    if suggestions:
        st.subheader("📌 Suggestions")
        for item in suggestions:
            st.write(f"• {item}")
    else:
        st.success("Keep maintaining the current study habits.")

    st.subheader("📊 Input Summary")
    st.dataframe(X.T.rename(columns={0: "Value"}), use_container_width=True)
